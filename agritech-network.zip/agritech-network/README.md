# Hyperledger Composer Marbles Demo

The Hyperledger Composer team has built an interactive, distributed, marble trading demo, backed by Hyperledger Fabric. Invite participants to join your distributed marble exchange, list marbles for sale and exchange marbles between participants.
